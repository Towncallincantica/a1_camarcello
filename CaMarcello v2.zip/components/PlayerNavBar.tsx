'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'

interface Props {
  episodeId: string
  playerId: string
}

const navItems = [
  { label: 'Storia', icon: '◈', path: '' },
  { label: 'Mappa', icon: '◎', path: '/map' },
  { label: 'Inventario', icon: '⬡', path: '/combine' },
  { label: 'Team', icon: '◉', path: '/team' },
  { label: 'Profilo', icon: '◇', path: '/profile' },
]

export function PlayerNavBar({ episodeId, playerId }: Props) {
  const pathname = usePathname()
  const base = `/play/${episodeId}`

  return (
    <nav style={{
      position: 'fixed',
      bottom: '1.5rem',
      left: '50%',
      transform: 'translateX(-50%)',
      zIndex: 100,
      display: 'flex',
      alignItems: 'center',
      gap: '0.25rem',
      background: 'rgba(9,8,7,0.92)',
      border: '1px solid rgba(254,234,165,0.15)',
      borderRadius: '999px',
      padding: '0.5rem 0.75rem',
      backdropFilter: 'blur(12px)',
      boxShadow: '0 0 0 1px rgba(254,234,165,0.05), 0 8px 32px rgba(0,0,0,0.6)',
    }}>
      {navItems.map((item) => {
        const href = `${base}${item.path}`
        const isActive = item.path === ''
          ? pathname === base
          : pathname.startsWith(href)

        return (
          <Link
            key={item.path}
            href={href}
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '0.2rem',
              padding: '0.4rem 0.75rem',
              borderRadius: '999px',
              textDecoration: 'none',
              transition: 'background 0.15s',
              background: isActive ? 'rgba(254,234,165,0.1)' : 'transparent',
              minWidth: '3.5rem',
            }}
          >
            <span style={{
              fontSize: '1rem',
              color: isActive ? '#feeaa5' : 'rgba(255,255,255,0.35)',
              lineHeight: 1,
              transition: 'color 0.15s',
            }}>
              {item.icon}
            </span>
            <span style={{
              fontSize: '0.6rem',
              letterSpacing: '0.06em',
              color: isActive ? '#feeaa5' : 'rgba(255,255,255,0.3)',
              textTransform: 'uppercase',
              transition: 'color 0.15s',
            }}>
              {item.label}
            </span>
          </Link>
        )
      })}
    </nav>
  )
}