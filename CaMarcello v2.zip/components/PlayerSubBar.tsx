'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useMemo } from 'react'

interface StatusEffect {
  status_effect_id: string
  status_type: string
  expires_at: string | null
}

interface Props {
  playerId: string
  episodeId: string
  teamName?: string | null
}

export function PlayerSubBar({ playerId, episodeId, teamName }: Props) {
  const [gpsStatus, setGpsStatus] = useState<'idle' | 'ok' | 'error'>('idle')
  const [statusEffects, setStatusEffects] = useState<StatusEffect[]>([])

  const supabase = useMemo(() => createClient(), [])

  // GPS status listener — riceve eventi da GPSUploader via CustomEvent
  useEffect(() => {
    function onGpsOk() { setGpsStatus('ok') }
    function onGpsError() { setGpsStatus('error') }

    window.addEventListener('gps:ok', onGpsOk)
    window.addEventListener('gps:error', onGpsError)

    return () => {
      window.removeEventListener('gps:ok', onGpsOk)
      window.removeEventListener('gps:error', onGpsError)
    }
  }, [])

  // Status effects realtime
  useEffect(() => {
    // Carica iniziali
    supabase
      .from('player_status_effects')
      .select('status_effect_id, status_type, expires_at')
      .eq('player_id', playerId)
      .eq('episode_id', episodeId)
      .then(({ data }) => {
        if (data) setStatusEffects(filterActive(data))
      })

    // Realtime insert
    const channel = supabase
      .channel(`status_effects:${playerId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'player_status_effects',
          filter: `player_id=eq.${playerId}`,
        },
        (payload) => {
          const effect = payload.new as StatusEffect
          setStatusEffects((prev) => filterActive([...prev, effect]))
        }
      )
      .subscribe()

    return () => { supabase.removeChannel(channel) }
  }, [supabase, playerId, episodeId])

  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      gap: '0.75rem',
      padding: '0.4rem 1.5rem',
      borderBottom: '1px solid rgba(255,255,255,0.04)',
      background: 'rgba(255,255,255,0.015)',
      fontSize: '0.72rem',
      color: 'rgba(255,255,255,0.35)',
      letterSpacing: '0.04em',
      flexWrap: 'wrap',
      minHeight: '2rem',
    }}>

      {/* GPS */}
      <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
        <span style={{
          width: '6px',
          height: '6px',
          borderRadius: '50%',
          background: gpsStatus === 'ok'
            ? '#64d278'
            : gpsStatus === 'error'
            ? '#e85555'
            : 'rgba(255,255,255,0.2)',
          display: 'inline-block',
          flexShrink: 0,
        }} />
        GPS
      </span>

      {/* Separator */}
      {teamName && <span style={{ color: 'rgba(255,255,255,0.1)' }}>·</span>}

      {/* Team */}
      {teamName && (
        <span style={{ color: 'rgba(255,255,255,0.4)' }}>
          ◉ {teamName}
        </span>
      )}

      {/* Status effects */}
      {statusEffects.map((effect) => (
        <span key={effect.status_effect_id} style={{
          padding: '0.1rem 0.5rem',
          border: '1px solid rgba(254,234,165,0.2)',
          borderRadius: '999px',
          color: '#feeaa5',
          fontSize: '0.65rem',
          letterSpacing: '0.06em',
        }}>
          {effect.status_type}
          {effect.expires_at && (
            <span style={{ color: 'rgba(254,234,165,0.5)', marginLeft: '0.3rem' }}>
              {formatExpiry(effect.expires_at)}
            </span>
          )}
        </span>
      ))}

    </div>
  )
}

function filterActive(effects: StatusEffect[]): StatusEffect[] {
  const now = new Date()
  return effects.filter(
    (e) => !e.expires_at || new Date(e.expires_at) > now
  )
}

function formatExpiry(expiresAt: string): string {
  const diff = Math.max(0, new Date(expiresAt).getTime() - Date.now())
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return '<1m'
  if (mins < 60) return `${mins}m`
  return `${Math.floor(mins / 60)}h`
}