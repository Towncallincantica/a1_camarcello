import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { ADVENTURE_ID } from '@/lib/constants'
import { PlayerNavBar } from '@/components/PlayerNavBar'
import { PlayerSubBar } from '@/components/PlayerSubBar'
import GPSUploader from '@/components/GPSUploader'
import { ExchangeRedirectListener } from '@/components/ExchangeRedirectListener'

export default async function EpisodeLayout({
  children,
  params,
}: {
  children: React.ReactNode
  params: Promise<{ episodeId: string }>
}) {
  const { episodeId } = await params
  const supabase = await createClient()

  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const { data: player } = await supabase
    .from('player')
    .select('player_id, display_name')
    .eq('user_id', user.id)
    .eq('adventure_id', ADVENTURE_ID)
    .single()
  if (!player) redirect('/play')

  // Team name (opzionale — null se non ha team)
  const { data: stats } = await supabase
    .from('player_episode_stats')
    .select('team_id')
    .eq('player_id', player.player_id)
    .eq('episode_id', episodeId)
    .single()

  let teamName: string | null = null
  if (stats?.team_id) {
    const { data: team } = await supabase
      .from('teams')
      .select('name')
      .eq('team_id', stats.team_id)
      .single()
    teamName = team?.name ?? null
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: '#090807',
      color: '#e8e4dc',
      fontFamily: 'Georgia, serif',
      display: 'flex',
      flexDirection: 'column',
    }}>
      {/* GPS upload silenzioso — attivo su tutte le route /play/[episodeId] */}
      <GPSUploader />

      {/* Listener scambio in arrivo */}
      <ExchangeRedirectListener
        playerId={player.player_id}
        episodeId={episodeId}
      />

      {/* SubBar — GPS status + team + status effects */}
      <PlayerSubBar
        playerId={player.player_id}
        episodeId={episodeId}
        teamName={teamName}
      />

      {/* Contenuto della pagina */}
      <div style={{ flex: 1, paddingBottom: '5rem' }}>
        {children}
      </div>

      {/* NavBar floating in basso */}
      <PlayerNavBar
        episodeId={episodeId}
        playerId={player.player_id}
      />
    </div>
  )
}