import { createClient } from '@/lib/supabase/server'
import { revalidatePath } from 'next/cache'
import { ADVENTURE_ID } from '@/lib/constants'

async function createItem(formData: FormData) {
  'use server'
  const supabase = await createClient()

  const { error } = await supabase.from('items').insert({
    adventure_id: ADVENTURE_ID,
    name: formData.get('name') as string,
    description: (formData.get('description') as string) || null,
    category: (formData.get('category') as string) || null,
    rarity: (formData.get('rarity') as string) || 'common',
    is_stackable: formData.get('is_stackable') === 'true',
    is_consumable: formData.get('is_consumable') === 'true',
    max_stack: Number(formData.get('max_stack') || 99),
    claim_code: (formData.get('claim_code') as string) || null,
    claim_limit: formData.get('claim_limit') ? Number(formData.get('claim_limit')) : null,
  })

  if (error) throw new Error(error.message)
  revalidatePath('/admin/items')
}

async function deleteItem(itemId: string) {
  'use server'
  const supabase = await createClient()
  const { error } = await supabase.from('items').delete().eq('item_id', itemId)
  if (error) throw new Error(error.message)
  revalidatePath('/admin/items')
}

const rarityColors: Record<string, string> = {
  common: 'bg-gray-800 text-gray-300',
  uncommon: 'bg-green-900 text-green-300',
  rare: 'bg-blue-900 text-blue-300',
  epic: 'bg-purple-900 text-purple-300',
  legendary: 'bg-yellow-900 text-yellow-300',
}

export default async function ItemsPage() {
  const supabase = await createClient()

  const { data: items } = await supabase
    .from('items')
    .select('item_id, name, description, category, rarity, is_stackable, is_consumable, max_stack, claim_code, claim_limit, episode_id, adventure_id')
    .eq('adventure_id', ADVENTURE_ID)
    .order('name', { ascending: true })

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-bold">Items</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">

        {/* ITEM LIST */}
        <div>
          <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-4">
            Catalog ({items?.length ?? 0})
          </h3>

          {items && items.length > 0 ? (
            <div className="space-y-3">
              {items.map((item) => (
                <div key={item.item_id} className="bg-gray-900 rounded-xl p-5">
                  <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <p className="font-medium text-white">{item.name}</p>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${rarityColors[item.rarity] ?? rarityColors.common}`}>
                          {item.rarity}
                        </span>
                        {item.category && (
                          <span className="text-xs px-2 py-0.5 rounded-full bg-gray-800 text-gray-400">
                            {item.category}
                          </span>
                        )}
                      </div>
                      {item.description && (
                        <p className="text-xs text-gray-500 truncate">{item.description}</p>
                      )}
                      <div className="flex items-center gap-3 mt-2 text-xs text-gray-600 flex-wrap">
                        {item.is_stackable && <span>stackable ×{item.max_stack}</span>}
                        {item.is_consumable && <span>consumable</span>}
                        {item.claim_code && (
                          <span className="font-mono text-gray-500">code: {item.claim_code}</span>
                        )}
                        {item.claim_limit && <span>limit: {item.claim_limit}</span>}
                      </div>
                      <p className="text-xs text-gray-700 mt-1 font-mono truncate">{item.item_id}</p>
                    </div>
                    <form action={deleteItem.bind(null, item.item_id)}>
                      <button type="submit" className="shrink-0 text-xs text-red-400 hover:text-red-300">
                        Delete
                      </button>
                    </form>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-gray-900 rounded-xl p-12 text-center">
              <p className="text-gray-400">No items yet.</p>
            </div>
          )}
        </div>

        {/* CREATE FORM */}
        <div>
          <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-4">
            New Item
          </h3>
          <div className="bg-gray-900 rounded-xl p-6">
            <form action={createItem} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Name <span className="text-red-400">*</span>
                </label>
                <input
                  name="name"
                  required
                  placeholder="Chiave Arrugginita"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Description</label>
                <textarea
                  name="description"
                  rows={2}
                  placeholder="Una vecchia chiave arrugginita..."
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Category</label>
                  <input
                    name="category"
                    placeholder="key, document, weapon..."
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Rarity</label>
                  <select
                    name="rarity"
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="common">Common</option>
                    <option value="uncommon">Uncommon</option>
                    <option value="rare">Rare</option>
                    <option value="epic">Epic</option>
                    <option value="legendary">Legendary</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Stackable</label>
                  <select
                    name="is_stackable"
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="true">Yes</option>
                    <option value="false">No</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Consumable</label>
                  <select
                    name="is_consumable"
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Max Stack</label>
                  <input
                    name="max_stack"
                    type="number"
                    min={1}
                    defaultValue={99}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Claim Code</label>
                  <input
                    name="claim_code"
                    placeholder="CHIAVE42"
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Claim Limit</label>
                  <input
                    name="claim_limit"
                    type="number"
                    min={1}
                    placeholder="— unlimited"
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium rounded-lg transition-colors"
              >
                Create Item
              </button>
            </form>
          </div>
        </div>

      </div>
    </div>
  )
}