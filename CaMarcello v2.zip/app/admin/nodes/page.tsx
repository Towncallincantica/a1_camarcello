import { createClient } from '@/lib/supabase/server'
import { ADVENTURE_ID } from '@/lib/constants'
import { redirect } from 'next/navigation'

async function createNode(formData: FormData) {
  'use server'
  const supabase = await createClient()
  const episode_id = formData.get('episode_id') as string
  const name = formData.get('name') as string
  const node_category = formData.get('node_category') as string
  const content_html = formData.get('content_html') as string

  await supabase.from('content_nodes').insert({
    episode_id,
    name,
    node_category,
    content_html,
  })

  redirect('/admin/nodes')
}

export default async function AdminNodesPage() {
  const supabase = await createClient()

  const { data: episodes } = await supabase
    .from('episodes')
    .select('episode_id, name')
    .eq('adventure_id', ADVENTURE_ID)
    .eq('is_active', true)
    .order('created_at', { ascending: true })

  const { data: nodes } = await supabase
    .from('content_nodes')
    .select(`
      node_id, name, node_category, created_at,
      episodes ( name )
    `)
    .order('created_at', { ascending: true })

  const categories = ['main_story', 'side_quest', 'exploration', 'social', 'combat', 'puzzle']

  return (
    <div>
      <h1 style={{ color: '#feeaa5', fontSize: '1.3rem', letterSpacing: '0.08em', marginBottom: '2rem' }}>
        NODI
      </h1>

      {/* Form creazione */}
      <div style={{
        background: 'rgba(255,255,255,0.03)',
        border: '1px solid rgba(255,255,255,0.08)',
        padding: '1.5rem',
        marginBottom: '2rem',
      }}>
        <h2 style={{ color: '#feeaa5', fontSize: '0.9rem', letterSpacing: '0.1em', marginBottom: '1.25rem' }}>
          NUOVO NODO
        </h2>
        <form action={createNode} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <div>
              <label style={labelStyle}>Episodio</label>
              <select name="episode_id" required style={inputStyle}>
                {episodes?.map(ep => (
                  <option key={ep.episode_id} value={ep.episode_id}>{ep.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label style={labelStyle}>Categoria</label>
              <select name="node_category" required style={inputStyle}>
                {categories.map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>
          <div>
            <label style={labelStyle}>Nome nodo</label>
            <input type="text" name="name" required style={inputStyle} placeholder="Es. La lettera misteriosa" />
          </div>
          <div>
            <label style={labelStyle}>Contenuto HTML</label>
            <textarea
              name="content_html"
              rows={4}
              style={{ ...inputStyle, resize: 'vertical' }}
              placeholder="<p>Testo narrativo del nodo...</p>"
            />
          </div>
          <div>
            <button type="submit" style={buttonStyle}>
              Crea nodo
            </button>
          </div>
        </form>
      </div>

      {/* Lista nodi */}
      <div>
        <h2 style={{ color: '#feeaa5', fontSize: '0.9rem', letterSpacing: '0.1em', marginBottom: '1rem' }}>
          NODI ESISTENTI ({nodes?.length ?? 0})
        </h2>
        {!nodes || nodes.length === 0 ? (
          <p style={{ color: 'rgba(255,255,255,0.4)' }}>Nessun nodo creato.</p>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.88rem' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
                {['Nome', 'Categoria', 'Episodio', 'Azioni'].map(h => (
                  <th key={h} style={{ padding: '0.75rem', textAlign: 'left', color: 'rgba(255,255,255,0.4)', fontWeight: 'normal', letterSpacing: '0.08em' }}>
                    {h.toUpperCase()}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {nodes.map(node => (
                <tr key={node.node_id} style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                  <td style={{ padding: '0.75rem', color: '#e8e4dc' }}>{node.name}</td>
                  <td style={{ padding: '0.75rem', color: 'rgba(255,255,255,0.5)', fontSize: '0.8rem' }}>{node.node_category}</td>
                  <td style={{ padding: '0.75rem', color: 'rgba(255,255,255,0.5)', fontSize: '0.8rem' }}>
                    {(node.episodes as any)?.name ?? '—'}
                  </td>
                  <td style={{ padding: '0.75rem' }}>
                    <a href={`/admin/nodes/${node.node_id}`} style={{ color: '#feeaa5', fontSize: '0.8rem', textDecoration: 'none' }}>
                      Gestisci →
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}

const labelStyle: React.CSSProperties = {
  display: 'block',
  fontSize: '0.75rem',
  letterSpacing: '0.08em',
  color: 'rgba(255,255,255,0.4)',
  marginBottom: '0.4rem',
}

const inputStyle: React.CSSProperties = {
  width: '100%',
  background: 'rgba(255,255,255,0.05)',
  border: '1px solid rgba(255,255,255,0.12)',
  color: '#e8e4dc',
  padding: '0.6rem 0.75rem',
  fontSize: '0.9rem',
  boxSizing: 'border-box',
  fontFamily: 'Georgia, serif',
}

const buttonStyle: React.CSSProperties = {
  background: 'rgba(254,234,165,0.1)',
  border: '1px solid #feeaa5',
  color: '#feeaa5',
  padding: '0.6rem 1.5rem',
  fontSize: '0.9rem',
  cursor: 'pointer',
  fontFamily: 'Georgia, serif',
  letterSpacing: '0.05em',
}