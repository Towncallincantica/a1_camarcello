import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'
import { redirect } from 'next/navigation'
import { ADVENTURE_ID } from '@/lib/constants'

async function createEpisode(formData: FormData) {
  'use server'
  const supabase = await createClient()

  const name = formData.get('name') as string
  const description = (formData.get('description') as string) || null
  const start_datetime = formData.get('start_datetime') as string
  const end_datetime = (formData.get('end_datetime') as string) || null
  const max_players = formData.get('max_players') ? Number(formData.get('max_players')) : null
  const join_mode = (formData.get('join_mode') as string) || 'free'
  const physical_location = (formData.get('physical_location') as string) || null

  const { data: episode, error } = await supabase
    .from('episodes')
    .insert({
      adventure_id: ADVENTURE_ID,
      name,
      description,
      start_datetime,
      end_datetime,
      max_players,
      join_mode,
      physical_location,
      is_active: true,
      is_published: false,
    })
    .select('episode_id')
    .single()

  if (error) throw new Error(error.message)

  redirect(`/admin/episodes/${episode.episode_id}/editor`)
}

export default async function EpisodesPage() {
  const supabase = await createClient()

  const { data: episodes } = await supabase
    .from('episodes')
    .select('episode_id, name, description, start_datetime, end_datetime, is_published, join_mode, max_players')
    .eq('adventure_id', ADVENTURE_ID)
    .order('start_datetime', { ascending: false })

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-bold">Episodes</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">

        {/* EPISODE LIST */}
        <div>
          <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-4">
            All Episodes
          </h3>

          {episodes && episodes.length > 0 ? (
            <div className="space-y-3">
              {episodes.map((ep) => (
                <div key={ep.episode_id} className="bg-gray-900 rounded-xl p-5">
                  <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium text-white truncate">{ep.name}</p>
                        <span className={`shrink-0 text-xs px-2 py-0.5 rounded-full ${
                          ep.is_published
                            ? 'bg-green-900 text-green-300'
                            : 'bg-gray-800 text-gray-400'
                        }`}>
                          {ep.is_published ? 'Published' : 'Draft'}
                        </span>
                      </div>
                      {ep.description && (
                        <p className="text-xs text-gray-500 truncate">{ep.description}</p>
                      )}
                      <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                        {ep.start_datetime && (
                          <span>
                            {new Date(ep.start_datetime).toLocaleDateString('it-IT', {
                              day: '2-digit',
                              month: 'short',
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        )}
                        <span className="bg-gray-800 px-1.5 py-0.5 rounded">{ep.join_mode}</span>
                        {ep.max_players && <span>max {ep.max_players}</span>}
                      </div>
                    </div>
                    <Link
                      href={`/admin/episodes/${ep.episode_id}/editor`}
                      className="shrink-0 text-sm text-indigo-400 hover:text-indigo-300"
                    >
                      Editor →
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-gray-900 rounded-xl p-12 text-center">
              <p className="text-gray-400">No episodes yet.</p>
            </div>
          )}
        </div>

        {/* CREATE FORM */}
        <div>
          <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-4">
            New Episode
          </h3>
          <div className="bg-gray-900 rounded-xl p-6">
            <form action={createEpisode} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Name <span className="text-red-400">*</span>
                </label>
                <input
                  name="name"
                  required
                  placeholder="Ca' Marcello — Novembre 2026"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Description</label>
                <textarea
                  name="description"
                  rows={3}
                  placeholder="Breve descrizione dell'episodio..."
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Start <span className="text-red-400">*</span>
                  </label>
                  <input
                    name="start_datetime"
                    type="datetime-local"
                    required
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">End</label>
                  <input
                    name="end_datetime"
                    type="datetime-local"
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Location</label>
                <input
                  name="physical_location"
                  placeholder="Villa Ca' Marcello, Piombino Dese"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Join Mode</label>
                  <select
                    name="join_mode"
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="free">Free</option>
                    <option value="invite">Invite Only</option>
                    <option value="code">Code</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Max Players</label>
                  <input
                    name="max_players"
                    type="number"
                    min={1}
                    placeholder="—"
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium rounded-lg transition-colors"
              >
                Create Episode →
              </button>
            </form>
          </div>
        </div>

      </div>
    </div>
  )
}