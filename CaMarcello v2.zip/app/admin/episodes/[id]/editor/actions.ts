'use server'

import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import type { Json, Enums } from '@/lib/database.types'

// ============================================================
// NODES
// ============================================================

export async function createNode(episodeId: string, formData: FormData) {
  const supabase = await createClient()

  const { data: node, error } = await supabase
    .from('content_nodes')
    .insert({
      episode_id: episodeId,
      name: formData.get('name') as string,
      node_category: formData.get('node_category') as Enums<'node_category'>,
      content_html: (formData.get('content_html') as string) || '',
    })
    .select('node_id')
    .single()

  if (error) throw new Error(error.message)

  await supabase.from('progress_items').insert({
    episode_id: episodeId,
    node_id: node.node_id,
    name: `Completed: ${formData.get('name')}`,
  })

  redirect(`/admin/episodes/${episodeId}/editor`)
}

export async function updateNode(episodeId: string, nodeId: string, formData: FormData) {
  const supabase = await createClient()

  const { error } = await supabase
    .from('content_nodes')
    .update({
      name: formData.get('name') as string,
      node_category: formData.get('node_category') as Enums<'node_category'>,
      content_html: (formData.get('content_html') as string) || '',
    })
    .eq('node_id', nodeId)

  if (error) throw new Error(error.message)

  redirect(`/admin/episodes/${episodeId}/editor`)
}

export async function deleteNode(episodeId: string, nodeId: string) {
  const supabase = await createClient()

  const { error } = await supabase
    .from('content_nodes')
    .delete()
    .eq('node_id', nodeId)

  if (error) throw new Error(error.message)

  redirect(`/admin/episodes/${episodeId}/editor`)
}

// ============================================================
// CONDITIONS
// ============================================================

export async function createCondition(episodeId: string, nodeId: string, formData: FormData) {
  const supabase = await createClient()

  const type = formData.get('type') as string
  let payload: Json = {}

  if (type === 'progress_item') {
    payload = { progress_item_id: formData.get('progress_item_id') as string }
  } else if (type === 'gps_location') {
    payload = {
      lat: Number(formData.get('lat')),
      lng: Number(formData.get('lng')),
      radius_m: Number(formData.get('radius_m')),
    }
  } else if (type === 'inventory_item') {
    payload = {
      item_id: formData.get('item_id') as string,
      quantity: Number(formData.get('quantity') || 1),
    }
  } else if (type === 'time_window') {
    payload = {
      starts_at: formData.get('starts_at') as string,
      ends_at: formData.get('ends_at') as string,
    }
  }

  const { error } = await supabase.from('conditions').insert({
    node_id: nodeId,
    episode_id: episodeId,
    type,
    payload,
  })

  if (error) throw new Error(error.message)

  redirect(`/admin/episodes/${episodeId}/editor/${nodeId}`)
}

export async function deleteCondition(episodeId: string, nodeId: string, conditionId: string) {
  const supabase = await createClient()

  const { error } = await supabase
    .from('conditions')
    .delete()
    .eq('condition_id', conditionId)

  if (error) throw new Error(error.message)

  redirect(`/admin/episodes/${episodeId}/editor/${nodeId}`)
}

// ============================================================
// TARGETS
// ============================================================

export async function createTarget(episodeId: string, nodeId: string, formData: FormData) {
  const supabase = await createClient()

  const type = formData.get('type') as string
  let payload: Json = {}

  if (type === 'gps_location') {
    payload = {
      lat: Number(formData.get('lat')),
      lng: Number(formData.get('lng')),
      radius_m: Number(formData.get('radius_m')),
      name: (formData.get('location_name') as string) || null,
    }
  } else if (type === 'qr_scan') {
    payload = { code: formData.get('code') as string }
  } else if (type === 'code_entry') {
    payload = { code: formData.get('code') as string }
  } else if (type === 'claim_item') {
    payload = { item_id: formData.get('item_id') as string }
  }

  const { error } = await supabase.from('targets').insert({
    node_id: nodeId,
    episode_id: episodeId,
    type,
    payload,
  })

  if (error) throw new Error(error.message)

  redirect(`/admin/episodes/${episodeId}/editor/${nodeId}`)
}

export async function deleteTarget(episodeId: string, nodeId: string, targetId: string) {
  const supabase = await createClient()

  const { error } = await supabase
    .from('targets')
    .delete()
    .eq('target_id', targetId)

  if (error) throw new Error(error.message)

  redirect(`/admin/episodes/${episodeId}/editor/${nodeId}`)
}

// ============================================================
// EFFECTS
// ============================================================

export async function createEffect(episodeId: string, nodeId: string, formData: FormData) {
  const supabase = await createClient()

  const type = formData.get('type') as string
  let payload: Json = {}

  if (type === 'grant_progress_item') {
    payload = { progress_item_id: formData.get('progress_item_id') as string }
  } else if (type === 'grant_inventory_item') {
    payload = {
      item_id: formData.get('item_id') as string,
      quantity: Number(formData.get('quantity') || 1),
    }
  } else if (type === 'modify_stat') {
    payload = {
      stat: formData.get('stat') as string,
      value: Number(formData.get('value')),
    }
  } else if (type === 'add_status_effect') {
    payload = {
      status_type: formData.get('status_type') as string,
      duration_minutes: formData.get('duration_minutes')
        ? Number(formData.get('duration_minutes'))
        : null,
    }
  }

  const { error } = await supabase.from('effects').insert({
    node_id: nodeId,
    episode_id: episodeId,
    type,
    payload,
  })

  if (error) throw new Error(error.message)

  redirect(`/admin/episodes/${episodeId}/editor/${nodeId}`)
}

export async function deleteEffect(episodeId: string, nodeId: string, effectId: string) {
  const supabase = await createClient()

  const { error } = await supabase
    .from('effects')
    .delete()
    .eq('effect_id', effectId)

  if (error) throw new Error(error.message)

  redirect(`/admin/episodes/${episodeId}/editor/${nodeId}`)
}